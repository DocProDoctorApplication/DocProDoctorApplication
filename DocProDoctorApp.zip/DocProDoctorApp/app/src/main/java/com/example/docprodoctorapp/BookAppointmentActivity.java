package com.example.docprodoctorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BookAppointmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appointment);
    }
}