package com.example.docprodoctorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class DutyDoctorActivity extends AppCompatActivity {

    private String[][] packages =
            {

                    {"Doctor Name : Harsha","Specialization  :Dentist","","MobileNo:7618782332",""},
                    {"Doctor Name : Raksitha","Specialization: Surgeon","","MobileNo:9945328808",""},
                    {"Doctor Name : D Chandan","Specialization : Detician","","MobileNo:9379625473",""},
                    {"Doctor Name : Janardhan","Specialization : Dentist","","MobileNo:6363963027",""},
                    {"Doctor Name : Deepthi","Specialization : Detician","","MobileNo:9363547350",""},
                    {"Doctor Name : Sony","Specialization : Cardiologist","","MobileNo:7618783225",""},
                    {"Doctor Name : Sandya M","Specialization : Surgeon","","MobileNo:7338145413",""},
                    {"Doctor Name : Spoorthi","Specialization : Family Physician","","MobileNo:9945328808",""},
            };
    HashMap<String,String> item;
    ArrayList list;
    SimpleAdapter sa;
    Button btnBack;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_test);

        btnBack = findViewById(R.id.buttonLTBack);
        listView = findViewById(R.id.listViewLTL);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DutyDoctorActivity.this,HomeActivity.class));
            }
        });
        list = new ArrayList();
        for (int i=0; i<packages.length;i++){
            item = new HashMap<String,String>();
            item.put("line1",packages[i][0]);
            item.put("line2",packages[i][1]);
            item.put("line3",packages[i][2]);
            item.put("line4",packages[i][3]);
            item.put("line5","Total Cost:"+packages[i][4]+"/-");
            list.add(item);
        }
        sa = new SimpleAdapter(this,list,
                R.layout.multi_lines,
                new String[]{ " line1","line2","line3","line4","line5"},
                new int[]{R.id.line_a,R.id.line_b,R.id.line_c,R.id.line_d,R.id.line_e});
        listView.setAdapter(sa);


    }
}